function Z = bt(X,Y)

Z = bsxfun(@times,X,Y);